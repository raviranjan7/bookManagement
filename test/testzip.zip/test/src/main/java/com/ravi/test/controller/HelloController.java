package com.ravi.test.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @RequestMapping("/hello")
    public String getHelloWorld(){
        return "Hello World";
    }
    @RequestMapping("/hello1")
    public String getHelloWorld1(){
        return "Hello World 1";
    }
}
